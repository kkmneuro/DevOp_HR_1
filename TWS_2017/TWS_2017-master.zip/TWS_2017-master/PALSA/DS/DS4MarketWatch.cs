﻿namespace PALSA.DS
{
    public partial class DS4MarketWatch
    {
        #region Nested type: dtMarketWatchDataTable

        partial class dtMarketWatchDataTable
        {
        }

        #endregion
    }
}