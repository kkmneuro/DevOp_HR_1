﻿namespace PALSA.DS
{
    public partial class DS4NetPosition
    {
        #region Nested type: dtNetPositionDataTable

        partial class dtNetPositionDataTable
        {
        }

        #endregion
    }
}