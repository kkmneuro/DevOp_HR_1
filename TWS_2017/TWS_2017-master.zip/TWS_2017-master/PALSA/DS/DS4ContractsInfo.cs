﻿namespace PALSA.DS {
    
    
    public partial class DS4ContractsInfo {
        partial class dtContractsDataTable
        {
        }
    }
}
