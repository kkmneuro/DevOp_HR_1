﻿namespace PALSA.DS
{
    public partial class DS4OrderHistory
    {
        #region Nested type: dtOrderHistoryDataTable

        partial class dtOrderHistoryDataTable
        {
    }

        #endregion
    }
}