﻿namespace PALSA.DS {
    
    
    public partial class DS4PositionClose {
        partial class dtPositionCloseDataTable
        {
        }
    }
}
