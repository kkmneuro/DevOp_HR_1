﻿namespace PALSA.DS
{
    public partial class DS4TradeHistory
    {
        #region Nested type: dtTradeHistoryDataTable

        partial class dtTradeHistoryDataTable
        {
        }

        #endregion
    }
}