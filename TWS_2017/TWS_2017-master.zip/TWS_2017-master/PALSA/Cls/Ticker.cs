﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PALSA.Cls
{
    public class Ticker
    {
        public int size;

        

        public string[] GetTickerText(int AccountGroupID)
        {
            return new string[1];
        }
    }
}
