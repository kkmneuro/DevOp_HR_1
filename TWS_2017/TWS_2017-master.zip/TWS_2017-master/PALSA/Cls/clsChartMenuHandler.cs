﻿namespace PALSA.Cls
{
    public class clsChartMenuHandler
    {
    }
}