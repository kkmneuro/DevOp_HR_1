﻿using System;

namespace M4.Charts
{
    internal struct Indicators
    {
        public int index;
        public string name;
    }
}
