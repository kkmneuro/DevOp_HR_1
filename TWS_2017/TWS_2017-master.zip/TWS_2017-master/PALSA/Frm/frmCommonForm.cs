﻿///////REVISION HISTORY/////////////////////////////////////////////////////////////////////////////////////////////////////
//DATE			INITIALS	DESCRIPTION
//17/01/2012	NAMO         Designing of form	
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

using System;

namespace PALSA.Frm
{
    public partial class frmCommonForm : frmBase
    {
        public frmCommonForm()
        {
            InitializeComponent();
        }

        private void frmCommonForm_Load(object sender, EventArgs e)
        {
        }
    }
}