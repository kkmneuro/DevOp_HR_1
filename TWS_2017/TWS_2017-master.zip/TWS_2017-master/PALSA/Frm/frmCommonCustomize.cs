﻿using System;

namespace PALSA.Frm
{
    public partial class frmCommonCustomize : frmBase
    {
        public frmCommonCustomize()
        {
            InitializeComponent();
        }

        private void frmCommonCustomize_Load(object sender, EventArgs e)
        {
        }
    }
}