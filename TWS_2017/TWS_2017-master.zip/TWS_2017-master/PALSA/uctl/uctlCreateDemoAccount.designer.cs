﻿namespace PALSA.uctl
{
    partial class uctlCreateDemoAccount
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.ui_npnlAccountPersonal = new Nevron.UI.WinForm.Controls.NUIPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.ui_lblFirstName = new System.Windows.Forms.Label();
            this.ui_ntxtFirstName = new Nevron.UI.WinForm.Controls.NTextBox();
            this.ui_lblEmail = new System.Windows.Forms.Label();
            this.ui_ntxtEmail = new Nevron.UI.WinForm.Controls.NTextBox();
            this.ui_pnlCountry = new System.Windows.Forms.Panel();
            this.ui_ntxtCountry = new Nevron.UI.WinForm.Controls.NTextBox();
            this.ui_ncmbCountry = new Nevron.UI.WinForm.Controls.NComboBox();
            this.ui_lblClientBalence = new System.Windows.Forms.Label();
            this.ui_ntxtBalence = new Nevron.UI.WinForm.Controls.NTextBox();
            this.ui_ntxtCurrencyName = new Nevron.UI.WinForm.Controls.NTextBox();
            this.ui_lblCurrency = new System.Windows.Forms.Label();
            this.ui_lblLeaverage = new System.Windows.Forms.Label();
            this.ui_ncmbLeverage = new Nevron.UI.WinForm.Controls.NComboBox();
            this.ui_nbtnCancel = new Nevron.UI.WinForm.Controls.NButton();
            this.ui_lblCountry = new System.Windows.Forms.Label();
            this.ui_nbtnOK = new Nevron.UI.WinForm.Controls.NButton();
            this.nProgressBar1 = new Nevron.UI.WinForm.Controls.NProgressBar();
            this.ui_nResultpnl = new Nevron.UI.WinForm.Controls.NUIPanel();
            this.ui_nbtnLogin = new Nevron.UI.WinForm.Controls.NButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ui_ntxtPassword = new Nevron.UI.WinForm.Controls.NTextBox();
            this.ui_ntxtLoginID = new Nevron.UI.WinForm.Controls.NTextBox();
            this.lblLogin = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.ui_npnlAccountPersonal.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.ui_pnlCountry.SuspendLayout();
            this.ui_nResultpnl.SuspendLayout();
            this.SuspendLayout();
            // 
            // ui_npnlAccountPersonal
            // 
            this.ui_npnlAccountPersonal.BackColor = System.Drawing.Color.Transparent;
            this.ui_npnlAccountPersonal.Controls.Add(this.tableLayoutPanel2);
            this.ui_npnlAccountPersonal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ui_npnlAccountPersonal.Location = new System.Drawing.Point(0, 0);
            this.ui_npnlAccountPersonal.Name = "ui_npnlAccountPersonal";
            this.ui_npnlAccountPersonal.Size = new System.Drawing.Size(421, 339);
            this.ui_npnlAccountPersonal.TabIndex = 4;
            this.ui_npnlAccountPersonal.Text = "nuiPanel1";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 18.66029F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 31.10048F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.26794F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.97129F));
            this.tableLayoutPanel2.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.ui_lblFirstName, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.ui_ntxtFirstName, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.ui_lblEmail, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.ui_ntxtEmail, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.ui_pnlCountry, 3, 2);
            this.tableLayoutPanel2.Controls.Add(this.ui_lblClientBalence, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.ui_ntxtBalence, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.ui_ntxtCurrencyName, 3, 3);
            this.tableLayoutPanel2.Controls.Add(this.ui_lblCurrency, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.ui_lblLeaverage, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.ui_ncmbLeverage, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.ui_nbtnCancel, 3, 8);
            this.tableLayoutPanel2.Controls.Add(this.ui_lblCountry, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.ui_nbtnOK, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.nProgressBar1, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.ui_nResultpnl, 0, 7);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 9;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(419, 337);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.tableLayoutPanel2.SetColumnSpan(this.label2, 4);
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(413, 29);
            this.label2.TabIndex = 122;
            this.label2.Text = "Demo Account";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ui_lblFirstName
            // 
            this.ui_lblFirstName.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.ui_lblFirstName.AutoSize = true;
            this.ui_lblFirstName.BackColor = System.Drawing.Color.Transparent;
            this.ui_lblFirstName.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ui_lblFirstName.Location = new System.Drawing.Point(3, 35);
            this.ui_lblFirstName.Name = "ui_lblFirstName";
            this.ui_lblFirstName.Size = new System.Drawing.Size(52, 13);
            this.ui_lblFirstName.TabIndex = 40;
            this.ui_lblFirstName.Text = "Name*:";
            // 
            // ui_ntxtFirstName
            // 
            this.tableLayoutPanel2.SetColumnSpan(this.ui_ntxtFirstName, 2);
            this.ui_ntxtFirstName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ui_ntxtFirstName.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ui_ntxtFirstName.Location = new System.Drawing.Point(81, 32);
            this.ui_ntxtFirstName.MaxLength = 50;
            this.ui_ntxtFirstName.Name = "ui_ntxtFirstName";
            this.ui_ntxtFirstName.Size = new System.Drawing.Size(192, 19);
            this.ui_ntxtFirstName.TabIndex = 3;
            this.ui_ntxtFirstName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ui_ntxtFirstName_KeyPress);
            // 
            // ui_lblEmail
            // 
            this.ui_lblEmail.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.ui_lblEmail.AutoSize = true;
            this.ui_lblEmail.BackColor = System.Drawing.Color.Transparent;
            this.ui_lblEmail.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ui_lblEmail.Location = new System.Drawing.Point(3, 60);
            this.ui_lblEmail.Name = "ui_lblEmail";
            this.ui_lblEmail.Size = new System.Drawing.Size(50, 13);
            this.ui_lblEmail.TabIndex = 46;
            this.ui_lblEmail.Text = "Email*:";
            this.ui_lblEmail.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ui_ntxtEmail
            // 
            this.tableLayoutPanel2.SetColumnSpan(this.ui_ntxtEmail, 2);
            this.ui_ntxtEmail.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ui_ntxtEmail.Location = new System.Drawing.Point(81, 57);
            this.ui_ntxtEmail.MaxLength = 50;
            this.ui_ntxtEmail.Name = "ui_ntxtEmail";
            this.ui_ntxtEmail.Size = new System.Drawing.Size(192, 19);
            this.ui_ntxtEmail.TabIndex = 16;
            // 
            // ui_pnlCountry
            // 
            this.ui_pnlCountry.Controls.Add(this.ui_ntxtCountry);
            this.ui_pnlCountry.Controls.Add(this.ui_ncmbCountry);
            this.ui_pnlCountry.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ui_pnlCountry.Location = new System.Drawing.Point(279, 57);
            this.ui_pnlCountry.Name = "ui_pnlCountry";
            this.ui_pnlCountry.Size = new System.Drawing.Size(137, 19);
            this.ui_pnlCountry.TabIndex = 10;
            // 
            // ui_ntxtCountry
            // 
            this.ui_ntxtCountry.Border.Style = Nevron.UI.BorderStyle3D.None;
            this.ui_ntxtCountry.Location = new System.Drawing.Point(-701, 23);
            this.ui_ntxtCountry.Name = "ui_ntxtCountry";
            this.ui_ntxtCountry.Size = new System.Drawing.Size(137, 14);
            this.ui_ntxtCountry.TabIndex = 10;
            this.ui_ntxtCountry.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ui_ntxtBankCountry_KeyUp);
            // 
            // ui_ncmbCountry
            // 
            this.ui_ncmbCountry.AcceptTextChangeOnReturnOnly = true;
            this.ui_ncmbCountry.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ui_ncmbCountry.Editable = true;
            this.ui_ncmbCountry.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ui_ncmbCountry.ListProperties.ColumnOnLeft = false;
            this.ui_ncmbCountry.Location = new System.Drawing.Point(0, 0);
            this.ui_ncmbCountry.Name = "ui_ncmbCountry";
            this.ui_ncmbCountry.Size = new System.Drawing.Size(137, 19);
            this.ui_ncmbCountry.TabIndex = 122;
            this.ui_ncmbCountry.TooltipInfo.ContentText = "Select Country";
            this.ui_ncmbCountry.TooltipInfo.InitialDelay = 300;
            this.ui_ncmbCountry.SelectedIndexChanged += new System.EventHandler(this.ui_ncmbCountry_SelectedIndexChanged);
            // 
            // ui_lblClientBalence
            // 
            this.ui_lblClientBalence.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.ui_lblClientBalence.AutoSize = true;
            this.ui_lblClientBalence.Location = new System.Drawing.Point(3, 84);
            this.ui_lblClientBalence.Name = "ui_lblClientBalence";
            this.ui_lblClientBalence.Size = new System.Drawing.Size(49, 13);
            this.ui_lblClientBalence.TabIndex = 117;
            this.ui_lblClientBalence.Text = "Deposit :";
            // 
            // ui_ntxtBalence
            // 
            this.ui_ntxtBalence.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ui_ntxtBalence.Location = new System.Drawing.Point(81, 82);
            this.ui_ntxtBalence.Name = "ui_ntxtBalence";
            this.ui_ntxtBalence.Size = new System.Drawing.Size(124, 18);
            this.ui_ntxtBalence.TabIndex = 1;
            this.ui_ntxtBalence.Text = "5000";
            // 
            // ui_ntxtCurrencyName
            // 
            this.ui_ntxtCurrencyName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ui_ntxtCurrencyName.Enabled = false;
            this.ui_ntxtCurrencyName.Location = new System.Drawing.Point(279, 82);
            this.ui_ntxtCurrencyName.Name = "ui_ntxtCurrencyName";
            this.ui_ntxtCurrencyName.ReadOnly = true;
            this.ui_ntxtCurrencyName.Size = new System.Drawing.Size(137, 18);
            this.ui_ntxtCurrencyName.TabIndex = 20;
            this.ui_ntxtCurrencyName.Text = "USD";
            // 
            // ui_lblCurrency
            // 
            this.ui_lblCurrency.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.ui_lblCurrency.AutoSize = true;
            this.ui_lblCurrency.Location = new System.Drawing.Point(211, 84);
            this.ui_lblCurrency.Name = "ui_lblCurrency";
            this.ui_lblCurrency.Size = new System.Drawing.Size(55, 13);
            this.ui_lblCurrency.TabIndex = 121;
            this.ui_lblCurrency.Text = "Currency :";
            // 
            // ui_lblLeaverage
            // 
            this.ui_lblLeaverage.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.ui_lblLeaverage.AutoSize = true;
            this.ui_lblLeaverage.BackColor = System.Drawing.Color.Transparent;
            this.ui_lblLeaverage.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ui_lblLeaverage.Location = new System.Drawing.Point(3, 110);
            this.ui_lblLeaverage.Name = "ui_lblLeaverage";
            this.ui_lblLeaverage.Size = new System.Drawing.Size(72, 13);
            this.ui_lblLeaverage.TabIndex = 55;
            this.ui_lblLeaverage.Text = "Leverage*:";
            this.ui_lblLeaverage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ui_ncmbLeverage
            // 
            this.ui_ncmbLeverage.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ui_ncmbLeverage.ListProperties.ColumnOnLeft = false;
            this.ui_ncmbLeverage.Location = new System.Drawing.Point(81, 106);
            this.ui_ncmbLeverage.Name = "ui_ncmbLeverage";
            this.ui_ncmbLeverage.Size = new System.Drawing.Size(124, 21);
            this.ui_ncmbLeverage.TabIndex = 19;
            this.ui_ncmbLeverage.TooltipInfo.ContentText = "Select Leverage Type";
            this.ui_ncmbLeverage.TooltipInfo.InitialDelay = 300;
            // 
            // ui_nbtnCancel
            // 
            this.ui_nbtnCancel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ui_nbtnCancel.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ui_nbtnCancel.Location = new System.Drawing.Point(297, 299);
            this.ui_nbtnCancel.Name = "ui_nbtnCancel";
            this.ui_nbtnCancel.Size = new System.Drawing.Size(101, 28);
            this.ui_nbtnCancel.TabIndex = 28;
            this.ui_nbtnCancel.Text = "Close";
            this.ui_nbtnCancel.UseVisualStyleBackColor = false;
            this.ui_nbtnCancel.Click += new System.EventHandler(this.ui_btnCancel_Click);
            // 
            // ui_lblCountry
            // 
            this.ui_lblCountry.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.ui_lblCountry.AutoSize = true;
            this.ui_lblCountry.BackColor = System.Drawing.Color.Transparent;
            this.ui_lblCountry.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ui_lblCountry.Location = new System.Drawing.Point(279, 35);
            this.ui_lblCountry.Name = "ui_lblCountry";
            this.ui_lblCountry.Size = new System.Drawing.Size(65, 13);
            this.ui_lblCountry.TabIndex = 52;
            this.ui_lblCountry.Text = "Country*:";
            this.ui_lblCountry.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ui_nbtnOK
            // 
            this.ui_nbtnOK.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tableLayoutPanel2.SetColumnSpan(this.ui_nbtnOK, 4);
            this.ui_nbtnOK.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ui_nbtnOK.Location = new System.Drawing.Point(55, 133);
            this.ui_nbtnOK.Name = "ui_nbtnOK";
            this.ui_nbtnOK.Size = new System.Drawing.Size(308, 28);
            this.ui_nbtnOK.TabIndex = 26;
            this.ui_nbtnOK.Text = "Create Account";
            this.ui_nbtnOK.UseVisualStyleBackColor = false;
            this.ui_nbtnOK.Click += new System.EventHandler(this.ui_btnOK_Click);
            // 
            // nProgressBar1
            // 
            this.nProgressBar1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tableLayoutPanel2.SetColumnSpan(this.nProgressBar1, 4);
            this.nProgressBar1.Cursor = System.Windows.Forms.Cursors.Default;
            this.nProgressBar1.Location = new System.Drawing.Point(12, 167);
            this.nProgressBar1.Name = "nProgressBar1";
            this.nProgressBar1.Properties.Style = Nevron.UI.WinForm.Controls.ProgressBarStyle.Gradient;
            this.nProgressBar1.Size = new System.Drawing.Size(395, 13);
            this.nProgressBar1.TabIndex = 123;
            this.nProgressBar1.Text = "nProgressBar1";
            // 
            // ui_nResultpnl
            // 
            this.tableLayoutPanel2.SetColumnSpan(this.ui_nResultpnl, 4);
            this.ui_nResultpnl.Controls.Add(this.ui_nbtnLogin);
            this.ui_nResultpnl.Controls.Add(this.label3);
            this.ui_nResultpnl.Controls.Add(this.label1);
            this.ui_nResultpnl.Controls.Add(this.ui_ntxtPassword);
            this.ui_nResultpnl.Controls.Add(this.ui_ntxtLoginID);
            this.ui_nResultpnl.Controls.Add(this.lblLogin);
            this.ui_nResultpnl.Cursor = System.Windows.Forms.Cursors.Default;
            this.ui_nResultpnl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ui_nResultpnl.Location = new System.Drawing.Point(3, 186);
            this.ui_nResultpnl.Name = "ui_nResultpnl";
            this.ui_nResultpnl.Size = new System.Drawing.Size(413, 100);
            this.ui_nResultpnl.TabIndex = 124;
            this.ui_nResultpnl.Text = "nuiPanel1";
            // 
            // ui_nbtnLogin
            // 
            this.ui_nbtnLogin.Cursor = System.Windows.Forms.Cursors.Default;
            this.ui_nbtnLogin.Location = new System.Drawing.Point(328, 61);
            this.ui_nbtnLogin.Name = "ui_nbtnLogin";
            this.ui_nbtnLogin.Size = new System.Drawing.Size(66, 23);
            this.ui_nbtnLogin.TabIndex = 5;
            this.ui_nbtnLogin.Text = "Login";
            this.ui_nbtnLogin.UseVisualStyleBackColor = false;
            this.ui_nbtnLogin.Click += new System.EventHandler(this.ui_nbtnLogin_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(273, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Note : Please keep your user loginId and password safe.";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Password :";
            // 
            // ui_ntxtPassword
            // 
            this.ui_ntxtPassword.Border.Style = Nevron.UI.BorderStyle3D.None;
            this.ui_ntxtPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ui_ntxtPassword.Location = new System.Drawing.Point(76, 33);
            this.ui_ntxtPassword.Name = "ui_ntxtPassword";
            this.ui_ntxtPassword.ReadOnly = true;
            this.ui_ntxtPassword.Size = new System.Drawing.Size(104, 16);
            this.ui_ntxtPassword.TabIndex = 2;
            // 
            // ui_ntxtLoginID
            // 
            this.ui_ntxtLoginID.Border.Style = Nevron.UI.BorderStyle3D.None;
            this.ui_ntxtLoginID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ui_ntxtLoginID.Location = new System.Drawing.Point(76, 10);
            this.ui_ntxtLoginID.Name = "ui_ntxtLoginID";
            this.ui_ntxtLoginID.ReadOnly = true;
            this.ui_ntxtLoginID.Size = new System.Drawing.Size(104, 16);
            this.ui_ntxtLoginID.TabIndex = 1;
            // 
            // lblLogin
            // 
            this.lblLogin.AutoSize = true;
            this.lblLogin.Location = new System.Drawing.Point(14, 12);
            this.lblLogin.Name = "lblLogin";
            this.lblLogin.Size = new System.Drawing.Size(53, 13);
            this.lblLogin.TabIndex = 0;
            this.lblLogin.Text = "Login ID :";
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            this.backgroundWorker1.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.backgroundWorker1_ProgressChanged);
            this.backgroundWorker1.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorker1_RunWorkerCompleted);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // uctlCreateDemoAccount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.ui_npnlAccountPersonal);
            this.Name = "uctlCreateDemoAccount";
            this.Size = new System.Drawing.Size(421, 339);
            this.Load += new System.EventHandler(this.uctlAccountPersonal_Load);
            this.ui_npnlAccountPersonal.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.ui_pnlCountry.ResumeLayout(false);
            this.ui_nResultpnl.ResumeLayout(false);
            this.ui_nResultpnl.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Nevron.UI.WinForm.Controls.NUIPanel ui_npnlAccountPersonal;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private Nevron.UI.WinForm.Controls.NComboBox ui_ncmbLeverage;
        private System.Windows.Forms.Label ui_lblLeaverage;
        private System.Windows.Forms.Label ui_lblFirstName;
        private Nevron.UI.WinForm.Controls.NButton ui_nbtnOK;
        private Nevron.UI.WinForm.Controls.NTextBox ui_ntxtFirstName;
        private Nevron.UI.WinForm.Controls.NTextBox ui_ntxtEmail;
        private System.Windows.Forms.Label ui_lblCountry;
        private System.Windows.Forms.Label ui_lblEmail;
        private System.Windows.Forms.Label ui_lblClientBalence;
        private Nevron.UI.WinForm.Controls.NTextBox ui_ntxtBalence;
        private Nevron.UI.WinForm.Controls.NButton ui_nbtnCancel;
        private Nevron.UI.WinForm.Controls.NTextBox ui_ntxtCurrencyName;
        private System.Windows.Forms.Label ui_lblCurrency;
        private System.Windows.Forms.Panel ui_pnlCountry;
        private Nevron.UI.WinForm.Controls.NTextBox ui_ntxtCountry;
        private Nevron.UI.WinForm.Controls.NComboBox ui_ncmbCountry;
        private System.Windows.Forms.Label label2;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Nevron.UI.WinForm.Controls.NProgressBar nProgressBar1;
        public Nevron.UI.WinForm.Controls.NUIPanel ui_nResultpnl;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private Nevron.UI.WinForm.Controls.NTextBox ui_ntxtPassword;
        private Nevron.UI.WinForm.Controls.NTextBox ui_ntxtLoginID;
        private System.Windows.Forms.Label lblLogin;
        private System.Windows.Forms.Timer timer1;
        private Nevron.UI.WinForm.Controls.NButton ui_nbtnLogin;
    }
}
