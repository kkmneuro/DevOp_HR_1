﻿
using PALSA.Cls;
using System.Drawing;
namespace PALSA.uctl
{
    partial class ctlMarketDepth
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ctlMarketDepth));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle46 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle47 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle48 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle49 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle50 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle51 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle52 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgvSymbol = new Nevron.UI.WinForm.Controls.NDataGridView();
            this.clSymbol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clBidTick = new System.Windows.Forms.DataGridViewImageColumn();
            this.clLast = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clNetChg = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clOpen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clHigh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clLow = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clClose = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clTrdSize = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.splContainerMain = new System.Windows.Forms.SplitContainer();
            this.splitContainerTopMain = new System.Windows.Forms.SplitContainer();
            this.splitContainerTop = new System.Windows.Forms.SplitContainer();
            this.dgvBidOfferCross = new PALSA.Cls.MarketDataGrid();
            this.colPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOrderSize = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOrderCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSpread = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NumberOfShares = new System.Windows.Forms.SplitContainer();
            this.clMarketDepthGraph = new PALSA.uctl.ctlMarketDepthGraph();
            this.splitContainerBottom = new System.Windows.Forms.SplitContainer();
            this.dgvBid = new PALSA.Cls.MarketDataGrid();
            this.clmId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmBid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmBidSize = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmBidTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvAsk = new PALSA.Cls.MarketDataGrid();
            this.clAskId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clAsk = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clAskSize = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clAskTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSymbol)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splContainerMain)).BeginInit();
            this.splContainerMain.Panel1.SuspendLayout();
            this.splContainerMain.Panel2.SuspendLayout();
            this.splContainerMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerTopMain)).BeginInit();
            this.splitContainerTopMain.Panel1.SuspendLayout();
            this.splitContainerTopMain.Panel2.SuspendLayout();
            this.splitContainerTopMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerTop)).BeginInit();
            this.splitContainerTop.Panel1.SuspendLayout();
            this.splitContainerTop.Panel2.SuspendLayout();
            this.splitContainerTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBidOfferCross)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumberOfShares)).BeginInit();
            this.NumberOfShares.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerBottom)).BeginInit();
            this.splitContainerBottom.Panel1.SuspendLayout();
            this.splitContainerBottom.Panel2.SuspendLayout();
            this.splitContainerBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAsk)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvSymbol
            // 
            this.dgvSymbol.AllowUserToAddRows = false;
            this.dgvSymbol.AllowUserToDeleteRows = false;
            this.dgvSymbol.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            this.dgvSymbol.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvSymbol.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSymbol.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSymbol.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvSymbol.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSymbol.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clSymbol,
            this.clBidTick,
            this.clLast,
            this.clNetChg,
            this.clOpen,
            this.clHigh,
            this.clLow,
            this.clClose,
            this.clTrdSize});
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvSymbol.DefaultCellStyle = dataGridViewCellStyle12;
            this.dgvSymbol.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgvSymbol.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvSymbol.GridColor = System.Drawing.Color.Black;
            this.dgvSymbol.Location = new System.Drawing.Point(0, 0);
            this.dgvSymbol.Name = "dgvSymbol";
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSymbol.RowHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dgvSymbol.RowHeadersVisible = false;
            this.dgvSymbol.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.dgvSymbol.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.dgvSymbol.Size = new System.Drawing.Size(657, 60);
            this.dgvSymbol.TabIndex = 0;
            // 
            // clSymbol
            // 
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            this.clSymbol.DefaultCellStyle = dataGridViewCellStyle3;
            this.clSymbol.HeaderText = "Symbol";
            this.clSymbol.Name = "clSymbol";
            this.clSymbol.ReadOnly = true;
            this.clSymbol.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // clBidTick
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.NullValue = ((object)(resources.GetObject("dataGridViewCellStyle4.NullValue")));
            this.clBidTick.DefaultCellStyle = dataGridViewCellStyle4;
            this.clBidTick.HeaderText = "Bid Tick";
            this.clBidTick.Name = "clBidTick";
            this.clBidTick.ReadOnly = true;
            this.clBidTick.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.clBidTick.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // clLast
            // 
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            this.clLast.DefaultCellStyle = dataGridViewCellStyle5;
            this.clLast.HeaderText = "Last";
            this.clLast.Name = "clLast";
            this.clLast.ReadOnly = true;
            // 
            // clNetChg
            // 
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            this.clNetChg.DefaultCellStyle = dataGridViewCellStyle6;
            this.clNetChg.HeaderText = "Net Chg";
            this.clNetChg.Name = "clNetChg";
            this.clNetChg.ReadOnly = true;
            // 
            // clOpen
            // 
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            this.clOpen.DefaultCellStyle = dataGridViewCellStyle7;
            this.clOpen.HeaderText = "Open";
            this.clOpen.Name = "clOpen";
            this.clOpen.ReadOnly = true;
            // 
            // clHigh
            // 
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black;
            this.clHigh.DefaultCellStyle = dataGridViewCellStyle8;
            this.clHigh.HeaderText = "High";
            this.clHigh.Name = "clHigh";
            this.clHigh.ReadOnly = true;
            // 
            // clLow
            // 
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.Black;
            this.clLow.DefaultCellStyle = dataGridViewCellStyle9;
            this.clLow.HeaderText = "Low";
            this.clLow.Name = "clLow";
            this.clLow.ReadOnly = true;
            // 
            // clClose
            // 
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            this.clClose.DefaultCellStyle = dataGridViewCellStyle10;
            this.clClose.HeaderText = "Close";
            this.clClose.Name = "clClose";
            this.clClose.ReadOnly = true;
            // 
            // clTrdSize
            // 
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.Black;
            this.clTrdSize.DefaultCellStyle = dataGridViewCellStyle11;
            this.clTrdSize.HeaderText = "Trd Size";
            this.clTrdSize.Name = "clTrdSize";
            this.clTrdSize.ReadOnly = true;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Up.png");
            this.imageList1.Images.SetKeyName(1, "down.png");
            this.imageList1.Images.SetKeyName(2, "empty.png");
            // 
            // splContainerMain
            // 
            this.splContainerMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splContainerMain.Location = new System.Drawing.Point(0, 60);
            this.splContainerMain.Name = "splContainerMain";
            this.splContainerMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splContainerMain.Panel1
            // 
            this.splContainerMain.Panel1.Controls.Add(this.splitContainerTopMain);
            // 
            // splContainerMain.Panel2
            // 
            this.splContainerMain.Panel2.Controls.Add(this.splitContainerBottom);
            this.splContainerMain.Size = new System.Drawing.Size(657, 475);
            this.splContainerMain.SplitterDistance = 127;
            this.splContainerMain.SplitterWidth = 5;
            this.splContainerMain.TabIndex = 1;
            // 
            // splitContainerTopMain
            // 
            this.splitContainerTopMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerTopMain.Location = new System.Drawing.Point(0, 0);
            this.splitContainerTopMain.Name = "splitContainerTopMain";
            this.splitContainerTopMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainerTopMain.Panel1
            // 
            this.splitContainerTopMain.Panel1.Controls.Add(this.splitContainerTop);
            // 
            // splitContainerTopMain.Panel2
            // 
            this.splitContainerTopMain.Panel2.BackColor = System.Drawing.Color.Black;
            this.splitContainerTopMain.Panel2.Controls.Add(this.clMarketDepthGraph);
            this.splitContainerTopMain.Size = new System.Drawing.Size(657, 127);
            this.splitContainerTopMain.SplitterDistance = 82;
            this.splitContainerTopMain.TabIndex = 1;
            // 
            // splitContainerTop
            // 
            this.splitContainerTop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerTop.Location = new System.Drawing.Point(0, 0);
            this.splitContainerTop.Name = "splitContainerTop";
            // 
            // splitContainerTop.Panel1
            // 
            this.splitContainerTop.Panel1.Controls.Add(this.dgvBidOfferCross);
            // 
            // splitContainerTop.Panel2
            // 
            this.splitContainerTop.Panel2.Controls.Add(this.NumberOfShares);
            this.splitContainerTop.Size = new System.Drawing.Size(657, 82);
            this.splitContainerTop.SplitterDistance = 219;
            this.splitContainerTop.TabIndex = 0;
            // 
            // dgvBidOfferCross
            // 
            this.dgvBidOfferCross.AllowUserToAddRows = false;
            this.dgvBidOfferCross.AllowUserToDeleteRows = false;
            this.dgvBidOfferCross.AllowUserToResizeColumns = false;
            this.dgvBidOfferCross.AllowUserToResizeRows = false;
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvBidOfferCross.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle14;
            this.dgvBidOfferCross.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvBidOfferCross.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvBidOfferCross.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.dgvBidOfferCross.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBidOfferCross.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colPrice,
            this.colOrderSize,
            this.colOrderCount,
            this.colSpread});
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvBidOfferCross.DefaultCellStyle = dataGridViewCellStyle16;
            this.dgvBidOfferCross.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvBidOfferCross.EnableCellCustomDraw = false;
            this.dgvBidOfferCross.GridColor = System.Drawing.Color.Black;
            this.dgvBidOfferCross.Location = new System.Drawing.Point(0, 0);
            this.dgvBidOfferCross.Name = "dgvBidOfferCross";
            this.dgvBidOfferCross.ReadOnly = true;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvBidOfferCross.RowHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.dgvBidOfferCross.RowHeadersVisible = false;
            this.dgvBidOfferCross.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.White;
            this.dgvBidOfferCross.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvBidOfferCross.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvBidOfferCross.Size = new System.Drawing.Size(219, 82);
            this.dgvBidOfferCross.TabIndex = 0;
            this.dgvBidOfferCross.VirtualMode = true;
            this.dgvBidOfferCross.CellValueNeeded += new System.Windows.Forms.DataGridViewCellValueEventHandler(this.dgvBidOfferCross_CellValueNeeded);
            // 
            // colPrice
            // 
            this.colPrice.HeaderText = "Price";
            this.colPrice.Name = "colPrice";
            this.colPrice.ReadOnly = true;
            // 
            // colOrderSize
            // 
            this.colOrderSize.HeaderText = "Size";
            this.colOrderSize.Name = "colOrderSize";
            this.colOrderSize.ReadOnly = true;
            // 
            // colOrderCount
            // 
            this.colOrderCount.HeaderText = "Orders";
            this.colOrderCount.Name = "colOrderCount";
            this.colOrderCount.ReadOnly = true;
            // 
            // colSpread
            // 
            this.colSpread.HeaderText = "Spread";
            this.colSpread.Name = "colSpread";
            this.colSpread.ReadOnly = true;
            // 
            // NumberOfShares
            // 
            this.NumberOfShares.BackColor = System.Drawing.Color.Red;
            this.NumberOfShares.Dock = System.Windows.Forms.DockStyle.Fill;
            this.NumberOfShares.Location = new System.Drawing.Point(0, 0);
            this.NumberOfShares.Name = "NumberOfShares";
            // 
            // NumberOfShares.Panel1
            // 
            this.NumberOfShares.Panel1.BackColor = System.Drawing.Color.Black;
            this.NumberOfShares.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.NumberOfShares_Panel1_Paint);
            // 
            // NumberOfShares.Panel2
            // 
            this.NumberOfShares.Panel2.BackColor = System.Drawing.Color.Black;
            this.NumberOfShares.Panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.NumberOfShares_Panel2_Paint);
            this.NumberOfShares.Size = new System.Drawing.Size(434, 82);
            this.NumberOfShares.SplitterDistance = 215;
            this.NumberOfShares.TabIndex = 0;
            // 
            // clMarketDepthGraph
            // 
            this.clMarketDepthGraph.BackColor = System.Drawing.Color.Black;
            this.clMarketDepthGraph.Dock = System.Windows.Forms.DockStyle.Fill;
            this.clMarketDepthGraph.Location = new System.Drawing.Point(0, 0);
            this.clMarketDepthGraph.Name = "clMarketDepthGraph";
            this.clMarketDepthGraph.Size = new System.Drawing.Size(657, 41);
            this.clMarketDepthGraph.TabIndex = 0;
            this.clMarketDepthGraph.Resize += new System.EventHandler(this.clMarketDepthGraph_Resize);
            // 
            // splitContainerBottom
            // 
            this.splitContainerBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerBottom.Location = new System.Drawing.Point(0, 0);
            this.splitContainerBottom.Name = "splitContainerBottom";
            // 
            // splitContainerBottom.Panel1
            // 
            this.splitContainerBottom.Panel1.Controls.Add(this.dgvBid);
            // 
            // splitContainerBottom.Panel2
            // 
            this.splitContainerBottom.Panel2.Controls.Add(this.dgvAsk);
            this.splitContainerBottom.Size = new System.Drawing.Size(657, 343);
            this.splitContainerBottom.SplitterDistance = 327;
            this.splitContainerBottom.TabIndex = 0;
            // 
            // dgvBid
            // 
            this.dgvBid.AllowUserToAddRows = false;
            this.dgvBid.AllowUserToDeleteRows = false;
            this.dgvBid.AllowUserToResizeRows = false;
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvBid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle18;
            this.dgvBid.BackgroundColor = global::PALSA.Properties.Settings.Default.backcolour_black;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvBid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.dgvBid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clmId,
            this.clmBid,
            this.clmBidSize,
            this.clmBidTime});
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvBid.DefaultCellStyle = dataGridViewCellStyle24;
            this.dgvBid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvBid.EnableCellCustomDraw = false;
            this.dgvBid.GridColor = System.Drawing.Color.Black;
            this.dgvBid.Location = new System.Drawing.Point(0, 0);
            this.dgvBid.MultiSelect = false;
            this.dgvBid.Name = "dgvBid";
            this.dgvBid.ReadOnly = true;
            this.dgvBid.RowHeadersVisible = false;
            this.dgvBid.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.White;
            this.dgvBid.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvBid.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvBid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvBid.ShowCellErrors = false;
            this.dgvBid.ShowCellToolTips = false;
            this.dgvBid.ShowEditingIcon = false;
            this.dgvBid.ShowRowErrors = false;
            this.dgvBid.Size = new System.Drawing.Size(327, 343);
            this.dgvBid.TabIndex = 0;
            this.dgvBid.VirtualMode = true;
            this.dgvBid.CellValueNeeded += new System.Windows.Forms.DataGridViewCellValueEventHandler(this.dgvBid_CellValueNeeded);
            this.dgvBid.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgvBid_DataError);
            // 
            // clmId
            // 
            dataGridViewCellStyle20.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.Color.Black;
            this.clmId.DefaultCellStyle = dataGridViewCellStyle20;
            this.clmId.HeaderText = "Liquid Provider";
            this.clmId.Name = "clmId";
            this.clmId.ReadOnly = true;
            this.clmId.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.clmId.Width = 58;
            // 
            // clmBid
            // 
            dataGridViewCellStyle21.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.Color.Black;
            this.clmBid.DefaultCellStyle = dataGridViewCellStyle21;
            this.clmBid.HeaderText = "Bid";
            this.clmBid.Name = "clmBid";
            this.clmBid.ReadOnly = true;
            this.clmBid.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.clmBid.Width = 58;
            // 
            // clmBidSize
            // 
            dataGridViewCellStyle22.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.Color.Black;
            this.clmBidSize.DefaultCellStyle = dataGridViewCellStyle22;
            this.clmBidSize.HeaderText = "Bid Volume (Billion)";
            this.clmBidSize.Name = "clmBidSize";
            this.clmBidSize.ReadOnly = true;
            this.clmBidSize.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.clmBidSize.Width = 58;
            // 
            // clmBidTime
            // 
            this.clmBidTime.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            dataGridViewCellStyle23.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.Color.Black;
            this.clmBidTime.DefaultCellStyle = dataGridViewCellStyle23;
            this.clmBidTime.HeaderText = "Time";
            this.clmBidTime.MinimumWidth = 150;
            this.clmBidTime.Name = "clmBidTime";
            this.clmBidTime.ReadOnly = true;
            this.clmBidTime.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.clmBidTime.Width = 150;
            // 
            // dgvAsk
            // 
            this.dgvAsk.AllowUserToAddRows = false;
            this.dgvAsk.AllowUserToDeleteRows = false;
            this.dgvAsk.AllowUserToResizeRows = false;
            this.dgvAsk.BackgroundColor = global::PALSA.Properties.Settings.Default.backcolour_black;
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle25.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle25.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAsk.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle25;
            this.dgvAsk.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAsk.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clAskId,
            this.clAsk,
            this.clAskSize,
            this.clAskTime});
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle30.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle30.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle30.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle30.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvAsk.DefaultCellStyle = dataGridViewCellStyle30;
            this.dgvAsk.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvAsk.EnableCellCustomDraw = false;
            this.dgvAsk.GridColor = System.Drawing.Color.Black;
            this.dgvAsk.Location = new System.Drawing.Point(0, 0);
            this.dgvAsk.MultiSelect = false;
            this.dgvAsk.Name = "dgvAsk";
            this.dgvAsk.ReadOnly = true;
            this.dgvAsk.RowHeadersVisible = false;
            this.dgvAsk.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.White;
            this.dgvAsk.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvAsk.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvAsk.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAsk.ShowCellErrors = false;
            this.dgvAsk.ShowCellToolTips = false;
            this.dgvAsk.ShowEditingIcon = false;
            this.dgvAsk.ShowRowErrors = false;
            this.dgvAsk.Size = new System.Drawing.Size(326, 343);
            this.dgvAsk.TabIndex = 0;
            this.dgvAsk.VirtualMode = true;
            this.dgvAsk.CellValueNeeded += new System.Windows.Forms.DataGridViewCellValueEventHandler(this.dgvAsk_CellValueNeeded);
            this.dgvAsk.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgvAsk_DataError);
            // 
            // clAskId
            // 
            dataGridViewCellStyle26.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.Color.Black;
            this.clAskId.DefaultCellStyle = dataGridViewCellStyle26;
            this.clAskId.HeaderText = "Liquid Provider";
            this.clAskId.Name = "clAskId";
            this.clAskId.ReadOnly = true;
            this.clAskId.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.clAskId.Width = 57;
            // 
            // clAsk
            // 
            dataGridViewCellStyle27.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.Color.Black;
            this.clAsk.DefaultCellStyle = dataGridViewCellStyle27;
            this.clAsk.HeaderText = "Offer";
            this.clAsk.Name = "clAsk";
            this.clAsk.ReadOnly = true;
            this.clAsk.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.clAsk.Width = 58;
            // 
            // clAskSize
            // 
            dataGridViewCellStyle28.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.Color.Black;
            this.clAskSize.DefaultCellStyle = dataGridViewCellStyle28;
            this.clAskSize.HeaderText = "Offer Volume (Billion)";
            this.clAskSize.Name = "clAskSize";
            this.clAskSize.ReadOnly = true;
            this.clAskSize.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.clAskSize.Width = 58;
            // 
            // clAskTime
            // 
            this.clAskTime.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            dataGridViewCellStyle29.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.Color.Black;
            this.clAskTime.DefaultCellStyle = dataGridViewCellStyle29;
            this.clAskTime.HeaderText = "Time";
            this.clAskTime.MinimumWidth = 150;
            this.clAskTime.Name = "clAskTime";
            this.clAskTime.ReadOnly = true;
            this.clAskTime.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.clAskTime.Width = 150;
            // 
            // dataGridViewImageColumn1
            // 
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle31.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle31.NullValue = ((object)(resources.GetObject("dataGridViewCellStyle31.NullValue")));
            this.dataGridViewImageColumn1.DefaultCellStyle = dataGridViewCellStyle31;
            this.dataGridViewImageColumn1.HeaderText = "Bid Tick";
            this.dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            this.dataGridViewImageColumn1.ReadOnly = true;
            this.dataGridViewImageColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewImageColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewImageColumn1.Width = 72;
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewCellStyle32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle32.ForeColor = System.Drawing.Color.White;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle32;
            this.dataGridViewTextBoxColumn1.HeaderText = "Symbol";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn1.Width = 73;
            // 
            // dataGridViewTextBoxColumn2
            // 
            dataGridViewCellStyle33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle33.ForeColor = System.Drawing.Color.White;
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle33;
            this.dataGridViewTextBoxColumn2.HeaderText = "Last";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 73;
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewCellStyle34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle34.ForeColor = System.Drawing.Color.White;
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle34;
            this.dataGridViewTextBoxColumn3.HeaderText = "Net Chg";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 73;
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewCellStyle35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle35.ForeColor = System.Drawing.Color.White;
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle35;
            this.dataGridViewTextBoxColumn4.HeaderText = "Open";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 72;
            // 
            // dataGridViewTextBoxColumn5
            // 
            dataGridViewCellStyle36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle36.ForeColor = System.Drawing.Color.White;
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle36;
            this.dataGridViewTextBoxColumn5.HeaderText = "High";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 73;
            // 
            // dataGridViewTextBoxColumn6
            // 
            dataGridViewCellStyle37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle37.ForeColor = System.Drawing.Color.White;
            this.dataGridViewTextBoxColumn6.DefaultCellStyle = dataGridViewCellStyle37;
            this.dataGridViewTextBoxColumn6.HeaderText = "Low";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 73;
            // 
            // dataGridViewTextBoxColumn7
            // 
            dataGridViewCellStyle38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle38.ForeColor = System.Drawing.Color.White;
            this.dataGridViewTextBoxColumn7.DefaultCellStyle = dataGridViewCellStyle38;
            this.dataGridViewTextBoxColumn7.HeaderText = "Close";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 72;
            // 
            // dataGridViewTextBoxColumn8
            // 
            dataGridViewCellStyle39.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewTextBoxColumn8.DefaultCellStyle = dataGridViewCellStyle39;
            this.dataGridViewTextBoxColumn8.HeaderText = "Trd Size";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn8.Width = 73;
            // 
            // dataGridViewTextBoxColumn9
            // 
            dataGridViewCellStyle40.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewTextBoxColumn9.DefaultCellStyle = dataGridViewCellStyle40;
            this.dataGridViewTextBoxColumn9.HeaderText = "Price";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn9.Width = 54;
            // 
            // dataGridViewTextBoxColumn10
            // 
            dataGridViewCellStyle41.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewTextBoxColumn10.DefaultCellStyle = dataGridViewCellStyle41;
            this.dataGridViewTextBoxColumn10.HeaderText = "Depth";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn10.Width = 54;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            dataGridViewCellStyle42.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewTextBoxColumn11.DefaultCellStyle = dataGridViewCellStyle42;
            this.dataGridViewTextBoxColumn11.HeaderText = "Size";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle43.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewTextBoxColumn12.DefaultCellStyle = dataGridViewCellStyle43;
            this.dataGridViewTextBoxColumn12.HeaderText = "Spread";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle44.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewTextBoxColumn13.DefaultCellStyle = dataGridViewCellStyle44;
            this.dataGridViewTextBoxColumn13.HeaderText = "Id";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn14
            // 
            dataGridViewCellStyle45.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewTextBoxColumn14.DefaultCellStyle = dataGridViewCellStyle45;
            this.dataGridViewTextBoxColumn14.HeaderText = "Bid";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn14.Visible = false;
            this.dataGridViewTextBoxColumn14.Width = 80;
            // 
            // dataGridViewTextBoxColumn15
            // 
            dataGridViewCellStyle46.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewTextBoxColumn15.DefaultCellStyle = dataGridViewCellStyle46;
            this.dataGridViewTextBoxColumn15.HeaderText = "Size";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn15.Width = 80;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle47.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewTextBoxColumn16.DefaultCellStyle = dataGridViewCellStyle47;
            this.dataGridViewTextBoxColumn16.HeaderText = "Time";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            this.dataGridViewTextBoxColumn16.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle48.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewTextBoxColumn17.DefaultCellStyle = dataGridViewCellStyle48;
            this.dataGridViewTextBoxColumn17.HeaderText = "Order";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            this.dataGridViewTextBoxColumn17.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle49.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewTextBoxColumn18.DefaultCellStyle = dataGridViewCellStyle49;
            this.dataGridViewTextBoxColumn18.HeaderText = "Bid";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            this.dataGridViewTextBoxColumn18.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle50.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewTextBoxColumn19.DefaultCellStyle = dataGridViewCellStyle50;
            this.dataGridViewTextBoxColumn19.HeaderText = "Size";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            this.dataGridViewTextBoxColumn19.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn20
            // 
            dataGridViewCellStyle51.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewTextBoxColumn20.DefaultCellStyle = dataGridViewCellStyle51;
            this.dataGridViewTextBoxColumn20.HeaderText = "Time";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            this.dataGridViewTextBoxColumn20.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn20.Visible = false;
            this.dataGridViewTextBoxColumn20.Width = 80;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle52.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewTextBoxColumn21.DefaultCellStyle = dataGridViewCellStyle52;
            this.dataGridViewTextBoxColumn21.HeaderText = "Order";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            // 
            // ctlMarketDepth
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = global::PALSA.Properties.Settings.Default.backcolour_black;
            this.Controls.Add(this.splContainerMain);
            this.Controls.Add(this.dgvSymbol);
            this.DoubleBuffered = true;
            this.Name = "ctlMarketDepth";
            this.Size = new System.Drawing.Size(657, 535);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSymbol)).EndInit();
            this.splContainerMain.Panel1.ResumeLayout(false);
            this.splContainerMain.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splContainerMain)).EndInit();
            this.splContainerMain.ResumeLayout(false);
            this.splitContainerTopMain.Panel1.ResumeLayout(false);
            this.splitContainerTopMain.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerTopMain)).EndInit();
            this.splitContainerTopMain.ResumeLayout(false);
            this.splitContainerTop.Panel1.ResumeLayout(false);
            this.splitContainerTop.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerTop)).EndInit();
            this.splitContainerTop.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBidOfferCross)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumberOfShares)).EndInit();
            this.NumberOfShares.ResumeLayout(false);
            this.splitContainerBottom.Panel1.ResumeLayout(false);
            this.splitContainerBottom.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerBottom)).EndInit();
            this.splitContainerBottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAsk)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Nevron.UI.WinForm.Controls.NDataGridView dgvSymbol;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.SplitContainer splContainerMain;
        private System.Windows.Forms.SplitContainer splitContainerTop;
        private System.Windows.Forms.SplitContainer splitContainerBottom;
        private MarketDataGrid dgvBidOfferCross;
        private MarketDataGrid dgvBid;
        private MarketDataGrid dgvAsk;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.SplitContainer NumberOfShares;
        private System.Windows.Forms.SplitContainer splitContainerTopMain;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private ctlMarketDepthGraph clMarketDepthGraph;
        private System.Windows.Forms.DataGridViewTextBoxColumn clSymbol;
        private System.Windows.Forms.DataGridViewImageColumn clBidTick;
        private System.Windows.Forms.DataGridViewTextBoxColumn clLast;
        private System.Windows.Forms.DataGridViewTextBoxColumn clNetChg;
        private System.Windows.Forms.DataGridViewTextBoxColumn clOpen;
        private System.Windows.Forms.DataGridViewTextBoxColumn clHigh;
        private System.Windows.Forms.DataGridViewTextBoxColumn clLow;
        private System.Windows.Forms.DataGridViewTextBoxColumn clClose;
        private System.Windows.Forms.DataGridViewTextBoxColumn clTrdSize;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOrderSize;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOrderCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSpread;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmId;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmBid;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmBidSize;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmBidTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn clAskId;
        private System.Windows.Forms.DataGridViewTextBoxColumn clAsk;
        private System.Windows.Forms.DataGridViewTextBoxColumn clAskSize;
        private System.Windows.Forms.DataGridViewTextBoxColumn clAskTime;
    }
}
