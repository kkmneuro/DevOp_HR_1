﻿namespace PALSA.uctl
{
    partial class uctlDealingDesk
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uctlDealingDesk));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            this.nuiPanel1 = new Nevron.UI.WinForm.Controls.NUIPanel();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.ui_uctlGridBottom = new CommonLibrary.UserControls.UctlGrid();
            this.ui_uctlGridMiddle = new CommonLibrary.UserControls.UctlGrid();
            this.ui_uctlGridTop = new CommonLibrary.UserControls.UctlGrid();
            this.ui_nbtnReject = new Nevron.UI.WinForm.Controls.NButton();
            this.ui_nbtnSendConfirm = new Nevron.UI.WinForm.Controls.NButton();
            this.ui_nbtnReturn = new Nevron.UI.WinForm.Controls.NButton();
            this.ui_nbtnRight = new Nevron.UI.WinForm.Controls.NButton();
            this.ui_nbtnLeft = new Nevron.UI.WinForm.Controls.NButton();
            this.ui_nbtnRightUp = new Nevron.UI.WinForm.Controls.NButton();
            this.ui_nbtnRightDown = new Nevron.UI.WinForm.Controls.NButton();
            this.ui_nbtnLeftUp = new Nevron.UI.WinForm.Controls.NButton();
            this.ui_nbtnLeftDown = new Nevron.UI.WinForm.Controls.NButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.lblAskValue = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.llblBidValue = new System.Windows.Forms.Label();
            this.nuiPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // nuiPanel1
            // 
            this.nuiPanel1.Controls.Add(this.label6);
            this.nuiPanel1.Controls.Add(this.label5);
            this.nuiPanel1.Controls.Add(this.label4);
            this.nuiPanel1.Controls.Add(this.label3);
            this.nuiPanel1.Controls.Add(this.ui_uctlGridBottom);
            this.nuiPanel1.Controls.Add(this.ui_uctlGridMiddle);
            this.nuiPanel1.Controls.Add(this.ui_uctlGridTop);
            this.nuiPanel1.Controls.Add(this.ui_nbtnReject);
            this.nuiPanel1.Controls.Add(this.ui_nbtnSendConfirm);
            this.nuiPanel1.Controls.Add(this.ui_nbtnReturn);
            this.nuiPanel1.Controls.Add(this.ui_nbtnRight);
            this.nuiPanel1.Controls.Add(this.ui_nbtnLeft);
            this.nuiPanel1.Controls.Add(this.ui_nbtnRightUp);
            this.nuiPanel1.Controls.Add(this.ui_nbtnRightDown);
            this.nuiPanel1.Controls.Add(this.ui_nbtnLeftUp);
            this.nuiPanel1.Controls.Add(this.ui_nbtnLeftDown);
            this.nuiPanel1.Controls.Add(this.panel1);
            this.nuiPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.nuiPanel1.Location = new System.Drawing.Point(0, 0);
            this.nuiPanel1.Name = "nuiPanel1";
            this.nuiPanel1.Size = new System.Drawing.Size(743, 414);
            this.nuiPanel1.TabIndex = 0;
            this.nuiPanel1.Text = "nuiPanel1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(526, 19);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 17);
            this.label6.TabIndex = 16;
            this.label6.Text = "label6";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(153, 50);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 17);
            this.label5.TabIndex = 15;
            this.label5.Text = "label5";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(153, 34);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 17);
            this.label4.TabIndex = 14;
            this.label4.Text = "label4";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(153, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 17);
            this.label3.TabIndex = 13;
            this.label3.Text = "label3";
            // 
            // ui_uctlGridBottom
            // 
            this.ui_uctlGridBottom.AllowUserToAddRows = true;
            this.ui_uctlGridBottom.AllowUserToDeleteRows = true;
            this.ui_uctlGridBottom.AllowUserToOrderColumns = true;
            this.ui_uctlGridBottom.AllowUserToResizeColumns = true;
            this.ui_uctlGridBottom.AllowUserToResizeRows = true;
            this.ui_uctlGridBottom.AlternatingRowStyle = dataGridViewCellStyle1;
            this.ui_uctlGridBottom.AutoSizeColumsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.ui_uctlGridBottom.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.ui_uctlGridBottom.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            this.ui_uctlGridBottom.ClipBoardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithAutoHeaderText;
            this.ui_uctlGridBottom.ColumnHeaderHeight = 23;
            this.ui_uctlGridBottom.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Raised;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ui_uctlGridBottom.ColumnHeadersCellStyle = dataGridViewCellStyle2;
            this.ui_uctlGridBottom.ColumnHeadersHeight = 0;
            this.ui_uctlGridBottom.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.ui_uctlGridBottom.ColumnHeadersVisible = true;
            this.ui_uctlGridBottom.DataGridBorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ui_uctlGridBottom.DataGridCellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Single;
            this.ui_uctlGridBottom.DataGridEditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystrokeOrF2;
            this.ui_uctlGridBottom.DataGridLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            this.ui_uctlGridBottom.DataGridScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ui_uctlGridBottom.DataGridSelectMode = System.Windows.Forms.DataGridViewSelectionMode.RowHeaderSelect;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.Padding = new System.Windows.Forms.Padding(0, 1, 0, 1);
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ui_uctlGridBottom.DataRowStyle = dataGridViewCellStyle3;
            this.ui_uctlGridBottom.DataSource = null;
            this.ui_uctlGridBottom.DefaultCellStyle = dataGridViewCellStyle3;
            this.ui_uctlGridBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.ui_uctlGridBottom.EnableCellCustomDraw = false;
            this.ui_uctlGridBottom.EnableHeaderCustomDraw = true;
            this.ui_uctlGridBottom.EnableHeadersVisualStyles = true;
            this.ui_uctlGridBottom.EnableMultiSelect = true;
            this.ui_uctlGridBottom.EnableSkinning = true;
            this.ui_uctlGridBottom.FirstDisplayedScrollingRowIndex = 0;
            this.ui_uctlGridBottom.GridForeColor = System.Drawing.SystemColors.ControlText;
            this.ui_uctlGridBottom.GridPalette = ((Nevron.UI.WinForm.Controls.NPalette)(resources.GetObject("ui_uctlGridBottom.GridPalette")));
            this.ui_uctlGridBottom.IColIndex = -1;
            this.ui_uctlGridBottom.IRowIndex = -1;
            this.ui_uctlGridBottom.IsGridReadOnly = true;
            this.ui_uctlGridBottom.IsGridVisible = true;
            this.ui_uctlGridBottom.IsRowHeadersVisible = false;
            this.ui_uctlGridBottom.Location = new System.Drawing.Point(0, 276);
            this.ui_uctlGridBottom.Name = "ui_uctlGridBottom";
            this.ui_uctlGridBottom.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Raised;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ui_uctlGridBottom.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.ui_uctlGridBottom.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.EnableResizing;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ui_uctlGridBottom.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.ui_uctlGridBottom.Size = new System.Drawing.Size(741, 136);
            this.ui_uctlGridBottom.TabIndex = 12;
            this.ui_uctlGridBottom.Title = null;
            // 
            // ui_uctlGridMiddle
            // 
            this.ui_uctlGridMiddle.AllowUserToAddRows = true;
            this.ui_uctlGridMiddle.AllowUserToDeleteRows = true;
            this.ui_uctlGridMiddle.AllowUserToOrderColumns = true;
            this.ui_uctlGridMiddle.AllowUserToResizeColumns = true;
            this.ui_uctlGridMiddle.AllowUserToResizeRows = true;
            this.ui_uctlGridMiddle.AlternatingRowStyle = dataGridViewCellStyle6;
            this.ui_uctlGridMiddle.AutoSizeColumsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.ui_uctlGridMiddle.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.ui_uctlGridMiddle.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            this.ui_uctlGridMiddle.ClipBoardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithAutoHeaderText;
            this.ui_uctlGridMiddle.ColumnHeaderHeight = 23;
            this.ui_uctlGridMiddle.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Raised;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ui_uctlGridMiddle.ColumnHeadersCellStyle = dataGridViewCellStyle7;
            this.ui_uctlGridMiddle.ColumnHeadersHeight = 0;
            this.ui_uctlGridMiddle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.ui_uctlGridMiddle.ColumnHeadersVisible = true;
            this.ui_uctlGridMiddle.DataGridBorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ui_uctlGridMiddle.DataGridCellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Single;
            this.ui_uctlGridMiddle.DataGridEditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystrokeOrF2;
            this.ui_uctlGridMiddle.DataGridLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            this.ui_uctlGridMiddle.DataGridScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ui_uctlGridMiddle.DataGridSelectMode = System.Windows.Forms.DataGridViewSelectionMode.RowHeaderSelect;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.Padding = new System.Windows.Forms.Padding(0, 1, 0, 1);
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ui_uctlGridMiddle.DataRowStyle = dataGridViewCellStyle8;
            this.ui_uctlGridMiddle.DataSource = null;
            this.ui_uctlGridMiddle.DefaultCellStyle = dataGridViewCellStyle8;
            this.ui_uctlGridMiddle.EnableCellCustomDraw = false;
            this.ui_uctlGridMiddle.EnableHeaderCustomDraw = true;
            this.ui_uctlGridMiddle.EnableHeadersVisualStyles = true;
            this.ui_uctlGridMiddle.EnableMultiSelect = true;
            this.ui_uctlGridMiddle.EnableSkinning = true;
            this.ui_uctlGridMiddle.FirstDisplayedScrollingRowIndex = 0;
            this.ui_uctlGridMiddle.GridForeColor = System.Drawing.SystemColors.ControlText;
            this.ui_uctlGridMiddle.GridPalette = ((Nevron.UI.WinForm.Controls.NPalette)(resources.GetObject("ui_uctlGridMiddle.GridPalette")));
            this.ui_uctlGridMiddle.IColIndex = -1;
            this.ui_uctlGridMiddle.IRowIndex = -1;
            this.ui_uctlGridMiddle.IsGridReadOnly = true;
            this.ui_uctlGridMiddle.IsGridVisible = true;
            this.ui_uctlGridMiddle.IsRowHeadersVisible = false;
            this.ui_uctlGridMiddle.Location = new System.Drawing.Point(0, 182);
            this.ui_uctlGridMiddle.Name = "ui_uctlGridMiddle";
            this.ui_uctlGridMiddle.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Raised;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ui_uctlGridMiddle.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.ui_uctlGridMiddle.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.EnableResizing;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ui_uctlGridMiddle.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.ui_uctlGridMiddle.Size = new System.Drawing.Size(741, 94);
            this.ui_uctlGridMiddle.TabIndex = 11;
            this.ui_uctlGridMiddle.Title = null;
            // 
            // ui_uctlGridTop
            // 
            this.ui_uctlGridTop.AllowUserToAddRows = true;
            this.ui_uctlGridTop.AllowUserToDeleteRows = true;
            this.ui_uctlGridTop.AllowUserToOrderColumns = true;
            this.ui_uctlGridTop.AllowUserToResizeColumns = true;
            this.ui_uctlGridTop.AllowUserToResizeRows = true;
            this.ui_uctlGridTop.AlternatingRowStyle = dataGridViewCellStyle11;
            this.ui_uctlGridTop.AutoSizeColumsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.ui_uctlGridTop.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.ui_uctlGridTop.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            this.ui_uctlGridTop.ClipBoardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithAutoHeaderText;
            this.ui_uctlGridTop.ColumnHeaderHeight = 23;
            this.ui_uctlGridTop.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Raised;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ui_uctlGridTop.ColumnHeadersCellStyle = dataGridViewCellStyle12;
            this.ui_uctlGridTop.ColumnHeadersHeight = 0;
            this.ui_uctlGridTop.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.ui_uctlGridTop.ColumnHeadersVisible = true;
            this.ui_uctlGridTop.DataGridBorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ui_uctlGridTop.DataGridCellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Single;
            this.ui_uctlGridTop.DataGridEditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystrokeOrF2;
            this.ui_uctlGridTop.DataGridLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            this.ui_uctlGridTop.DataGridScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ui_uctlGridTop.DataGridSelectMode = System.Windows.Forms.DataGridViewSelectionMode.RowHeaderSelect;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle13.Padding = new System.Windows.Forms.Padding(0, 1, 0, 1);
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ui_uctlGridTop.DataRowStyle = dataGridViewCellStyle13;
            this.ui_uctlGridTop.DataSource = null;
            this.ui_uctlGridTop.DefaultCellStyle = dataGridViewCellStyle13;
            this.ui_uctlGridTop.EnableCellCustomDraw = false;
            this.ui_uctlGridTop.EnableHeaderCustomDraw = true;
            this.ui_uctlGridTop.EnableHeadersVisualStyles = true;
            this.ui_uctlGridTop.EnableMultiSelect = true;
            this.ui_uctlGridTop.EnableSkinning = true;
            this.ui_uctlGridTop.FirstDisplayedScrollingRowIndex = 0;
            this.ui_uctlGridTop.GridForeColor = System.Drawing.SystemColors.ControlText;
            this.ui_uctlGridTop.GridPalette = ((Nevron.UI.WinForm.Controls.NPalette)(resources.GetObject("ui_uctlGridTop.GridPalette")));
            this.ui_uctlGridTop.IColIndex = -1;
            this.ui_uctlGridTop.IRowIndex = -1;
            this.ui_uctlGridTop.IsGridReadOnly = true;
            this.ui_uctlGridTop.IsGridVisible = true;
            this.ui_uctlGridTop.IsRowHeadersVisible = false;
            this.ui_uctlGridTop.Location = new System.Drawing.Point(0, 88);
            this.ui_uctlGridTop.Name = "ui_uctlGridTop";
            this.ui_uctlGridTop.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Raised;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ui_uctlGridTop.RowHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.ui_uctlGridTop.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.EnableResizing;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ui_uctlGridTop.RowsDefaultCellStyle = dataGridViewCellStyle15;
            this.ui_uctlGridTop.Size = new System.Drawing.Size(741, 93);
            this.ui_uctlGridTop.TabIndex = 10;
            this.ui_uctlGridTop.Title = null;
            // 
            // ui_nbtnReject
            // 
            this.ui_nbtnReject.Location = new System.Drawing.Point(414, 64);
            this.ui_nbtnReject.Name = "ui_nbtnReject";
            this.ui_nbtnReject.Size = new System.Drawing.Size(91, 18);
            this.ui_nbtnReject.TabIndex = 9;
            this.ui_nbtnReject.Text = "Reject";
            this.ui_nbtnReject.UseVisualStyleBackColor = false;
            this.ui_nbtnReject.Click += new System.EventHandler(this.ui_nbtnReject_Click);
            // 
            // ui_nbtnSendConfirm
            // 
            this.ui_nbtnSendConfirm.Location = new System.Drawing.Point(321, 64);
            this.ui_nbtnSendConfirm.Name = "ui_nbtnSendConfirm";
            this.ui_nbtnSendConfirm.Size = new System.Drawing.Size(91, 18);
            this.ui_nbtnSendConfirm.TabIndex = 8;
            this.ui_nbtnSendConfirm.Text = "Send/Confirm";
            this.ui_nbtnSendConfirm.UseVisualStyleBackColor = false;
            this.ui_nbtnSendConfirm.Click += new System.EventHandler(this.ui_nbtnSendConfirm_Click);
            // 
            // ui_nbtnReturn
            // 
            this.ui_nbtnReturn.Location = new System.Drawing.Point(228, 64);
            this.ui_nbtnReturn.Name = "ui_nbtnReturn";
            this.ui_nbtnReturn.Size = new System.Drawing.Size(91, 18);
            this.ui_nbtnReturn.TabIndex = 7;
            this.ui_nbtnReturn.Text = "Return";
            this.ui_nbtnReturn.UseVisualStyleBackColor = false;
            this.ui_nbtnReturn.Click += new System.EventHandler(this.ui_nbtnReturn_Click);
            // 
            // ui_nbtnRight
            // 
            this.ui_nbtnRight.Location = new System.Drawing.Point(506, 15);
            this.ui_nbtnRight.Name = "ui_nbtnRight";
            this.ui_nbtnRight.Size = new System.Drawing.Size(14, 48);
            this.ui_nbtnRight.TabIndex = 6;
            this.ui_nbtnRight.UseVisualStyleBackColor = false;
            this.ui_nbtnRight.Click += new System.EventHandler(this.ui_nbtnRight_Click);
            // 
            // ui_nbtnLeft
            // 
            this.ui_nbtnLeft.Location = new System.Drawing.Point(212, 15);
            this.ui_nbtnLeft.Name = "ui_nbtnLeft";
            this.ui_nbtnLeft.Size = new System.Drawing.Size(14, 48);
            this.ui_nbtnLeft.TabIndex = 5;
            this.ui_nbtnLeft.UseVisualStyleBackColor = false;
            this.ui_nbtnLeft.Click += new System.EventHandler(this.ui_nbtnLeft_Click);
            // 
            // ui_nbtnRightUp
            // 
            this.ui_nbtnRightUp.Location = new System.Drawing.Point(492, 15);
            this.ui_nbtnRightUp.Name = "ui_nbtnRightUp";
            this.ui_nbtnRightUp.Size = new System.Drawing.Size(13, 24);
            this.ui_nbtnRightUp.TabIndex = 4;
            this.ui_nbtnRightUp.UseVisualStyleBackColor = false;
            // 
            // ui_nbtnRightDown
            // 
            this.ui_nbtnRightDown.Location = new System.Drawing.Point(492, 38);
            this.ui_nbtnRightDown.Name = "ui_nbtnRightDown";
            this.ui_nbtnRightDown.Size = new System.Drawing.Size(13, 24);
            this.ui_nbtnRightDown.TabIndex = 3;
            this.ui_nbtnRightDown.UseVisualStyleBackColor = false;
            // 
            // ui_nbtnLeftUp
            // 
            this.ui_nbtnLeftUp.Location = new System.Drawing.Point(227, 15);
            this.ui_nbtnLeftUp.Name = "ui_nbtnLeftUp";
            this.ui_nbtnLeftUp.Size = new System.Drawing.Size(13, 24);
            this.ui_nbtnLeftUp.TabIndex = 2;
            this.ui_nbtnLeftUp.UseVisualStyleBackColor = false;
            // 
            // ui_nbtnLeftDown
            // 
            this.ui_nbtnLeftDown.Location = new System.Drawing.Point(227, 38);
            this.ui_nbtnLeftDown.Name = "ui_nbtnLeftDown";
            this.ui_nbtnLeftDown.Size = new System.Drawing.Size(13, 24);
            this.ui_nbtnLeftDown.TabIndex = 1;
            this.ui_nbtnLeftDown.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.ui_nbtnLeftDown.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.lblAskValue);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.llblBidValue);
            this.panel1.Location = new System.Drawing.Point(240, 15);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(252, 47);
            this.panel1.TabIndex = 0;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(112, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(15, 22);
            this.label9.TabIndex = 18;
            this.label9.Text = "/";
            // 
            // lblAskValue
            // 
            this.lblAskValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAskValue.Location = new System.Drawing.Point(127, 11);
            this.lblAskValue.Name = "lblAskValue";
            this.lblAskValue.Size = new System.Drawing.Size(56, 18);
            this.lblAskValue.TabIndex = 18;
            this.lblAskValue.Text = "label8";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(211, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "label2";
            // 
            // llblBidValue
            // 
            this.llblBidValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llblBidValue.Location = new System.Drawing.Point(64, 11);
            this.llblBidValue.Name = "llblBidValue";
            this.llblBidValue.Size = new System.Drawing.Size(56, 18);
            this.llblBidValue.TabIndex = 10;
            this.llblBidValue.Text = "label1";
            // 
            // uctlDealingDesk
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.nuiPanel1);
            this.Name = "uctlDealingDesk";
            this.Size = new System.Drawing.Size(743, 414);
            this.Load += new System.EventHandler(this.uctlDealingDesk_Load);
            this.nuiPanel1.ResumeLayout(false);
            this.nuiPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Nevron.UI.WinForm.Controls.NUIPanel nuiPanel1;
        private Nevron.UI.WinForm.Controls.NButton ui_nbtnRight;
        private Nevron.UI.WinForm.Controls.NButton ui_nbtnLeft;
        private Nevron.UI.WinForm.Controls.NButton ui_nbtnRightUp;
        private Nevron.UI.WinForm.Controls.NButton ui_nbtnRightDown;
        private Nevron.UI.WinForm.Controls.NButton ui_nbtnLeftUp;
        private Nevron.UI.WinForm.Controls.NButton ui_nbtnLeftDown;
        private System.Windows.Forms.Panel panel1;
        private Nevron.UI.WinForm.Controls.NButton ui_nbtnReject;
        private Nevron.UI.WinForm.Controls.NButton ui_nbtnSendConfirm;
        private Nevron.UI.WinForm.Controls.NButton ui_nbtnReturn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label llblBidValue;
        private CommonLibrary.UserControls.UctlGrid ui_uctlGridBottom;
        private CommonLibrary.UserControls.UctlGrid ui_uctlGridMiddle;
        private CommonLibrary.UserControls.UctlGrid ui_uctlGridTop;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblAskValue;
    }
}
