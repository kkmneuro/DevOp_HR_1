﻿namespace CommonLibrary.Cls
{
    internal class ClsMarketWatchSettings
    {
    }
}