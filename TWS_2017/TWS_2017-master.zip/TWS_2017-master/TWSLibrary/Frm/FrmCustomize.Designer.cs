﻿namespace CommonLibrary.UserControls
{
	partial class FrmCustomize
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

        private Nevron.UI.WinForm.Controls.NDataGridView ui_ndgvPreview;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private Nevron.UI.WinForm.Controls.NColorButton ui_ncbtnBackgroundColor;
        private Nevron.UI.WinForm.Controls.NColorButton ui_ncbtColor;
        private Nevron.UI.WinForm.Controls.NColorButton ui_ncbtnForegroundColor;



		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
        //private void InitializeComponent()
        //{
        //    this.SuspendLayout();
        //    // 
        //    // FrmCustomize
        //    // 
        //    this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
        //    this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        //    this.ClientSize = new System.Drawing.Size(292, 266);
        //    this.Name = "FrmCustomize";
        //    this.Text = "FrmCustomize";
        //    this.Load += new System.EventHandler(this.FrmCustomize_Load);
        //    this.ResumeLayout(false);

        //}

		#endregion
	}
}