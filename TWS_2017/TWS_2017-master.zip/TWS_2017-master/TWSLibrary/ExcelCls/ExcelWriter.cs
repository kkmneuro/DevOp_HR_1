// C# Excel Writer library v2.0
// by Serhiy Perevoznyk, 2008-2011

using System;
using System.IO;
using System.Text;

namespace XLSExportDemo
{
    /// <summary>
    /// Produces Excel file without using Excel
    /// </summary>
    public class ExcelWriter
    {
        private readonly ushort[] clBegin = {0x0809, 8, 0, 0x10, 0, 0};
        private readonly ushort[] clEnd = {0x0A, 00};
        private readonly BinaryWriter writer;
        private Stream _stream;


        /// <summary>
        /// Initializes a new instance of the <see cref="ExcelWriter"/> class.
        /// </summary>
        /// <param name="stream">The stream.</param>
        public ExcelWriter(Stream stream)
        {
            _stream = stream;
            writer = new BinaryWriter(stream);
        }

        private void WriteUshortArray(ushort[] value)
        {
            foreach (ushort t in value)
                writer.Write(t);
        }

        /// <summary>
        /// Writes the text cell value.
        /// </summary>
        /// <param name="row">The row.</param>
        /// <param name="col">The col.</param>
        /// <param name="value">The string value.</param>
        public void WriteCell(int row, int col, string value)
        {
            ushort[] clData = {0x0204, 0, 0, 0, 0, 0};
            int iLen = value.Length;
            byte[] plainText = Encoding.ASCII.GetBytes(value);
            clData[1] = (ushort) (8 + iLen);
            clData[2] = (ushort) row;
            clData[3] = (ushort) col;
            clData[5] = (ushort) iLen;
            WriteUshortArray(clData);
            writer.Write(plainText);
        }

        /// <summary>
        /// Writes the date format.
        /// </summary>
        /// <param name="value">The date format value.</param>
        public void WriteFormat(string value)
        {
            ushort[] clData = {0x001E, 0};
            byte[] plainText = Encoding.ASCII.GetBytes(value);
            int iLen = plainText.Length;
            clData[1] = (ushort) (1 + iLen);
            WriteUshortArray(clData);
            writer.Write((byte) iLen);
            writer.Write(plainText);
        }

        /// <summary>
        /// Writes the integer cell value.
        /// </summary>
        /// <param name="row">The row number.</param>
        /// <param name="col">The column number.</param>
        /// <param name="value">The value.</param>
        public void WriteCell(int row, int col, int value)
        {
            ushort[] clData = {0x027E, 10, 0, 0, 0};
            clData[2] = (ushort) row;
            clData[3] = (ushort) col;
            WriteUshortArray(clData);
            int iValue = (value << 2) | 2;
            writer.Write(iValue);
        }

        /// <summary>
        /// Writes the cell.
        /// </summary>
        /// <param name="row">The row.</param>
        /// <param name="col">The col.</param>
        /// <param name="value">The value.</param>
        /// <param name="formatIndex">Index of the date format.</param>
        public void WriteCell(int row, int col, DateTime value, int formatIndex)
        {
            var baseDate = new DateTime(1899, 12, 31);
            TimeSpan ts = value - baseDate;

            var days = (ushort) (ts.Days + 1);
            ushort[] clData = {0x0002, 09, 0, 0};
            clData[2] = (ushort) row;
            clData[3] = (ushort) col;
            WriteUshortArray(clData);
            writer.Write((byte) 0x0);
            var indexValue = (byte) (formatIndex & 0x3F);
            writer.Write(indexValue);
            writer.Write((byte) 0x0);
            writer.Write(days);
        }

        /// <summary>
        /// Writes the double cell value.
        /// </summary>
        /// <param name="row">The row number.</param>
        /// <param name="col">The column number.</param>
        /// <param name="value">The value.</param>
        public void WriteCell(int row, int col, double value)
        {
            ushort[] clData = {0x0203, 14, 0, 0, 0};
            clData[2] = (ushort) row;
            clData[3] = (ushort) col;
            WriteUshortArray(clData);
            writer.Write(value);
        }

        /// <summary>
        /// Writes the empty cell.
        /// </summary>
        /// <param name="row">The row number.</param>
        /// <param name="col">The column number.</param>
        public void WriteCell(int row, int col)
        {
            ushort[] clData = {0x0201, 6, 0, 0, 0x17};
            clData[2] = (ushort) row;
            clData[3] = (ushort) col;
            WriteUshortArray(clData);
        }

        /// <summary>
        /// Must be called once for creating XLS file header
        /// </summary>
        public void BeginWrite()
        {
            WriteUshortArray(clBegin);
        }

        /// <summary>
        /// Ends the writing operation, but do not close the stream
        /// </summary>
        public void EndWrite()
        {
            WriteUshortArray(clEnd);
            writer.Flush();
        }
    }
}