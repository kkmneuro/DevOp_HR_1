﻿// C# Excel Writer library v2.0
// by Serhiy Perevoznyk, 2008-2011

namespace XLSExportDemo
{
    public enum Alignment
    {
        General,
        Left,
        Centered,
        Right,
        Filled
    }
}