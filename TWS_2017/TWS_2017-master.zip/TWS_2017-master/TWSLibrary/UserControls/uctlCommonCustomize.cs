﻿namespace CommonLibrary.UserControls
{
    public partial class UctlCommonCustomize : UctlBase
    {
        public UctlCommonCustomize()
        {
            InitializeComponent();
        }
    }
}